import { useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Html, Environment, ContactShadows, Float, useCursor } from '@react-three/drei';
import * as THREE from 'three';
import { cn } from '../utils/cn';
import { Info } from 'lucide-react';

interface HotspotProps {
  position: [number, number, number];
  title: string;
  description: string;
  visible: boolean;
  active: boolean;
  onClick: () => void;
}

const Hotspot = ({ position, title, description, visible, active, onClick }: HotspotProps) => {
  const [hovered, setHovered] = useState(false);
  useCursor(hovered);

  if (!visible) return null;

  return (
    <Html position={position} center zIndexRange={[100, 0]}>
      <div
        className={cn(
          "relative group transition-transform duration-300 ease-out",
          active ? "scale-110 z-10" : "scale-100 hover:scale-105 z-0"
        )}
      >
        <button
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
          onClick={(e) => {
            e.stopPropagation();
            onClick();
          }}
          className={cn(
            "w-8 h-8 rounded-full flex items-center justify-center cursor-pointer shadow-lg backdrop-blur-md transition-all duration-300",
            active 
              ? "bg-blue-600/90 text-white shadow-blue-500/50 ring-2 ring-white" 
              : "bg-white/80 text-gray-800 hover:bg-white ring-1 ring-black/10 hover:ring-blue-400"
          )}
        >
          <Info size={16} className={cn(active && "animate-pulse")} />
        </button>

        {/* Tooltip */}
        <div
          className={cn(
            "absolute left-1/2 -translate-x-1/2 mt-3 w-48 p-3 rounded-lg bg-white/95 backdrop-blur-xl shadow-xl ring-1 ring-black/5 transition-all duration-300 pointer-events-none origin-top",
            active ? "opacity-100 scale-100 translate-y-0" : "opacity-0 scale-95 -translate-y-2"
          )}
        >
          <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-white/95 rotate-45 ring-1 ring-black/5 border-l border-t border-transparent" />
          <h4 className="text-sm font-semibold text-gray-900 mb-1 relative z-10">{title}</h4>
          <p className="text-xs text-gray-600 leading-relaxed relative z-10">{description}</p>
        </div>
      </div>
    </Html>
  );
};

interface SmartSpeakerProps {
  color: string;
}

const SmartSpeaker = ({ color }: SmartSpeakerProps) => {
  const meshRef = useRef<THREE.Group>(null);
  


  return (
    <group ref={meshRef} position={[0, -1.2, 0]}>
      {/* Base */}
      <mesh position={[0, 0.1, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[1.05, 1.1, 0.2, 64]} />
        <meshStandardMaterial color="#222" roughness={0.8} metalness={0.2} />
      </mesh>

      {/* Main Body */}
      <mesh name="body" position={[0, 1.6, 0]} castShadow receiveShadow>
        {/* We use a cylinder but with a subtle curve using a custom geometry or just high segments */}
        <cylinderGeometry args={[0.95, 1.05, 3, 64, 16]} />
        <meshStandardMaterial 
          color={color} 
          roughness={0.6} 
          metalness={0.1}
          envMapIntensity={1}
        />
      </mesh>

      {/* Top Bezel */}
      <mesh position={[0, 3.15, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[0.95, 0.95, 0.1, 64]} />
        <meshStandardMaterial color="#333" roughness={0.4} metalness={0.8} />
      </mesh>

      {/* Top Touch Panel */}
      <mesh position={[0, 3.2, 0]} receiveShadow>
        <cylinderGeometry args={[0.85, 0.85, 0.02, 64]} />
        <meshStandardMaterial color="#111" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* Light Ring */}
      <mesh position={[0, 3.1, 0]}>
        <cylinderGeometry args={[0.96, 0.96, 0.05, 64]} />
        <meshBasicMaterial color="#00f0ff" transparent opacity={0.8} />
      </mesh>
    </group>
  );
};

export interface HotspotData {
  id: string;
  position: [number, number, number];
  title: string;
  description: string;
}

const HOTSPOTS: HotspotData[] = [
  {
    id: "touch",
    position: [0, 2.5, 0.8],
    title: "Touch Controls",
    description: "Capacitive touch surface for intuitive volume and playback control."
  },
  {
    id: "audio",
    position: [1.2, 0.5, 0],
    title: "360° Audio",
    description: "Custom-designed transducers deliver rich, omnidirectional sound."
  },
  {
    id: "mic",
    position: [-0.9, 2.0, 0.9],
    title: "Mic Array",
    description: "Six-microphone array for far-field voice recognition, even in loud environments."
  }
];

interface ProductViewerProps {
  color: string;
  showHotspots: boolean;
  activeHotspot: string | null;
  onHotspotClick: (id: string) => void;
}

export default function ProductViewer({ 
  color, 
  showHotspots, 
  activeHotspot, 
  onHotspotClick 
}: ProductViewerProps) {
  return (
    <div className="w-full h-full relative cursor-grab active:cursor-grabbing bg-gray-50/50">
      <Canvas shadows camera={{ position: [4, 2, 5], fov: 45 }}>
        <color attach="background" args={['#f8fafc']} />
        
        {/* Lighting */}
        <ambientLight intensity={0.5} />
        <spotLight 
          position={[10, 10, 10]} 
          angle={0.15} 
          penumbra={1} 
          intensity={1.5} 
          castShadow 
          shadow-mapSize={[1024, 1024]}
        />
        <pointLight position={[-10, -10, -10]} intensity={0.5} />
        
        {/* Environment for reflections */}
        <Environment preset="city" />

        {/* 3D Model with Floating effect */}
        <Float speed={1.5} rotationIntensity={0.1} floatIntensity={0.5} floatingRange={[-0.1, 0.1]}>
          <SmartSpeaker color={color} />
          
          {HOTSPOTS.map((hotspot) => (
            <Hotspot
              key={hotspot.id}
              position={hotspot.position}
              title={hotspot.title}
              description={hotspot.description}
              visible={showHotspots}
              active={activeHotspot === hotspot.id}
              onClick={() => onHotspotClick(activeHotspot === hotspot.id ? '' : hotspot.id)}
            />
          ))}
        </Float>

        {/* Soft shadow on the ground */}
        <ContactShadows 
          position={[0, -1.3, 0]} 
          opacity={0.6} 
          scale={10} 
          blur={2.5} 
          far={4} 
        />

        {/* Controls */}
        <OrbitControls 
          enablePan={false}
          minPolarAngle={Math.PI / 4}
          maxPolarAngle={Math.PI / 1.5}
          minDistance={3}
          maxDistance={8}
          autoRotate={!activeHotspot}
          autoRotateSpeed={1}
        />
      </Canvas>

      {/* Overlays / Instructions */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 pointer-events-none flex flex-col items-center gap-2 opacity-60">
         <span className="text-sm font-medium text-gray-500 bg-white/80 px-4 py-1.5 rounded-full shadow-sm backdrop-blur-sm border border-gray-100">
           Drag to rotate • Scroll to zoom
         </span>
      </div>
    </div>
  );
}

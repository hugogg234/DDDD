import { useState } from 'react';
import ProductViewer from './components/ProductViewer';
import { cn } from './utils/cn';
import { Check, Info, Settings2, ShieldCheck, Truck } from 'lucide-react';

const COLORS = [
  { id: 'black', name: 'Midnight Black', value: '#1a1a1a', tailwind: 'bg-zinc-900' },
  { id: 'white', name: 'Glacier White', value: '#f0f0f0', tailwind: 'bg-gray-100' },
  { id: 'blue', name: 'Ocean Blue', value: '#0369a1', tailwind: 'bg-sky-700' },
  { id: 'red', name: 'Coral Red', value: '#be123c', tailwind: 'bg-rose-700' },
];

const FEATURES = [
  { icon: ShieldCheck, text: "2 Year Warranty" },
  { icon: Truck, text: "Free Global Shipping" },
  { icon: Settings2, text: "Customizable EQ" },
];

export default function App() {
  const [activeColor, setActiveColor] = useState(COLORS[0]);
  const [showHotspots, setShowHotspots] = useState(true);
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-white overflow-hidden font-sans">
      
      {/* Left Column: 3D Viewer */}
      <div className="flex-1 relative h-[60vh] md:h-screen border-b md:border-b-0 md:border-r border-gray-200">
        <ProductViewer 
          color={activeColor.value}
          showHotspots={showHotspots}
          activeHotspot={activeHotspot}
          onHotspotClick={(id) => setActiveHotspot(id || null)}
        />
      </div>

      {/* Right Column: Product Details */}
      <div className="w-full md:w-[450px] lg:w-[500px] bg-white h-full overflow-y-auto custom-scrollbar flex flex-col">
        <div className="p-8 lg:p-12 flex-1">
          
          <div className="mb-2">
            <span className="text-sm font-bold tracking-wider text-blue-600 uppercase">New Release</span>
          </div>
          
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">
            Aura Sound <br/> Pro Max
          </h1>
          
          <p className="text-2xl font-light text-gray-500 mb-8">
            $299.00
          </p>

          <p className="text-gray-600 leading-relaxed mb-10">
            Experience spatial audio like never before. The Aura Sound Pro Max combines computational audio with custom acoustics to create a soundstage that completely immerses you.
          </p>

          <hr className="border-gray-100 mb-10" />

          {/* Color Selection */}
          <div className="mb-10">
            <h3 className="text-sm font-semibold text-gray-900 mb-4 uppercase tracking-wider">
              Color — <span className="text-gray-500">{activeColor.name}</span>
            </h3>
            <div className="flex gap-4">
              {COLORS.map((color) => (
                <button
                  key={color.id}
                  onClick={() => setActiveColor(color)}
                  className={cn(
                    "w-12 h-12 rounded-full relative flex items-center justify-center transition-transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-blue-100",
                    color.tailwind
                  )}
                  aria-label={`Select ${color.name}`}
                >
                  {activeColor.id === color.id && (
                    <Check 
                      size={20} 
                      className={cn(
                        "absolute",
                        color.id === 'white' ? 'text-gray-900' : 'text-white'
                      )} 
                    />
                  )}
                  <span className={cn(
                    "absolute inset-0 rounded-full border-2 transition-opacity duration-300 pointer-events-none",
                    activeColor.id === color.id ? "border-gray-900 opacity-100 scale-110" : "border-transparent opacity-0"
                  )} />
                </button>
              ))}
            </div>
          </div>

          {/* Hotspot Controls */}
          <div className="mb-10 p-6 bg-gray-50 rounded-2xl border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-gray-900 font-semibold">
                <Info size={18} className="text-blue-500" />
                Interactive Features
              </div>
              <button
                onClick={() => {
                  setShowHotspots(!showHotspots);
                  if (showHotspots) setActiveHotspot(null);
                }}
                className={cn(
                  "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2",
                  showHotspots ? 'bg-blue-600' : 'bg-gray-300'
                )}
              >
                <span
                  className={cn(
                    "inline-block h-4 w-4 transform rounded-full bg-white transition-transform",
                    showHotspots ? 'translate-x-6' : 'translate-x-1'
                  )}
                />
              </button>
            </div>
            <p className="text-sm text-gray-500">
              Toggle the annotations on the 3D model to explore key technical features.
            </p>
          </div>

          {/* Quick Features */}
          <ul className="space-y-4 mb-10">
            {FEATURES.map((feature, idx) => (
              <li key={idx} className="flex items-center gap-3 text-gray-700">
                <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <feature.icon size={16} />
                </div>
                <span className="font-medium text-sm">{feature.text}</span>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Sticky Checkout Bar */}
        <div className="sticky bottom-0 p-6 bg-white border-t border-gray-100 flex gap-4">
          <button className="flex-1 bg-gray-900 hover:bg-black text-white font-semibold py-4 px-6 rounded-xl transition-all active:scale-[0.98] shadow-lg shadow-gray-900/20">
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
